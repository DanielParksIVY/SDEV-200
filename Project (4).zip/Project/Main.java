import java.awt.event.ActionEvent;
import java.util.Random;
import javax.swing.*;

public class Main {
    private static Timer jobTimer;
    private static Random random = new Random();
    private static GameWindow gameWindow;
    static String filePath = "standby_workers.txt";

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            WorkerManager workerManager = new WorkerManager(5, 10, filePath); // 5 types, 10 workers each
            gameWindow = new GameWindow(workerManager);
            JobManager jobManager = new JobManager(workerManager, gameWindow);

            // Create a method to schedule the next job with random intervals
            scheduleNextJob(jobManager);
        });
    }

    private static void scheduleNextJob(JobManager jobManager) {
        // Randomize the interval
        int randomInterval = random.nextInt(1000) + 5000; // Random delay between 5-6 seconds

        // Create a new Timer with the random interval
        jobTimer = new Timer(randomInterval, (ActionEvent e) -> {
            jobManager.createJob();
            // After creating a job, schedule the next one with a new random interval
            scheduleNextJob(jobManager);
        });

        jobTimer.setRepeats(false); // Ensure the timer only runs once for this job creation
        jobTimer.start();
    }
}
