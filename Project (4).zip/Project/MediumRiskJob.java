public class MediumRiskJob extends Job {
    public MediumRiskJob(WorkerManager workerManager, int workersNeeded, int workerType, GameWindow gameWindow) {
        super(workerManager, workersNeeded, workerType, gameWindow);
    }

    @Override
    protected int getDuration() {
        return (int) (Math.random() * 7000) + 14000;
    }

    @Override
    protected boolean determineSuccess() {
        return Math.random() < 0.5;
    }
}
