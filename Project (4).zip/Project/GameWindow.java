import java.awt.*;
import java.util.List;
import javax.swing.*;

public class GameWindow extends JFrame {
    private final WorkerManager workerManager;
    private final JLabel[][] workerLabels;
    private final JPanel activeJobsPanel;

    public GameWindow(WorkerManager workerManager) {
        this.workerManager = workerManager;
        setTitle("Worker Management Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLayout(new BorderLayout());

        // Initialize the worker labels
        int workerCount = workerManager.getStandbyWorkers().length;
        workerLabels = new JLabel[workerCount][2];
        JPanel workerPanel = new JPanel(new GridLayout(workerCount, 2));

        for (int i = 0; i < workerCount; i++) {
            workerPanel.add(new JLabel("Worker Type " + (i + 1) + ":"));
            workerLabels[i][0] = new JLabel("Standby: " + workerManager.getStandbyWorkers()[i]);
            workerLabels[i][1] = new JLabel("Working: " + workerManager.getWorkingWorkers()[i]);
            workerPanel.add(workerLabels[i][0]);
            workerPanel.add(workerLabels[i][1]);
        }

        // Add worker panel to the center of the frame
        add(workerPanel, BorderLayout.CENTER);

        // Setup active jobs panel
        activeJobsPanel = new JPanel();
        activeJobsPanel.setLayout(new BoxLayout(activeJobsPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(activeJobsPanel);
        scrollPane.setPreferredSize(new Dimension(200, 200));
        add(scrollPane, BorderLayout.EAST);

        // Finalize frame setup
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void updateActiveJobs(List<Job> activeJobs) {
        activeJobsPanel.removeAll();
        for (Job job : activeJobs) {
            JLabel jobLabel = new JLabel(String.format("Job: Type %d, Workers: %d", job.getWorkerType() + 1, job.getWorkersNeeded()));
            activeJobsPanel.add(jobLabel);
        }
        activeJobsPanel.revalidate();
        activeJobsPanel.repaint();
    }

    public void updateDisplay() {
        for (int i = 0; i < workerManager.getStandbyWorkers().length; i++) {
            workerLabels[i][0].setText("Standby: " + workerManager.getStandbyWorkers()[i]);
            workerLabels[i][1].setText("Working: " + workerManager.getWorkingWorkers()[i]);
        }
    }
}
