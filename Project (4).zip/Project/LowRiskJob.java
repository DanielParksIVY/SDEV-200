public class LowRiskJob extends Job {
    public LowRiskJob(WorkerManager workerManager, int workersNeeded, int workerType, GameWindow gameWindow) {
        super(workerManager, workersNeeded, workerType, gameWindow);
    }

    @Override
    protected int getDuration() {
        return (int) (Math.random() * 1000) + 5000;
    }

    @Override
    protected boolean determineSuccess() {
        return Math.random() < 0.90;
    }
}
