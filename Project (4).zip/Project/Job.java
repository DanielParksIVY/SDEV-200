import javax.swing.JOptionPane;

public abstract class Job {
    protected int workersNeeded;
    protected int workerType; // Type of workers needed for the job
    protected WorkerManager workerManager;
    protected GameWindow gameWindow;
    private boolean isActive;

    public Job(WorkerManager workerManager, int workersNeeded, int workerType, GameWindow gameWindow) {
        this.workersNeeded = workersNeeded;
        this.workerType = workerType;
        this.workerManager = workerManager;
        this.gameWindow = gameWindow;
        this.isActive = true; // Initially, job is active
    }

    public void startJob() {
        new Thread(() -> {
            try {
                Thread.sleep(getDuration());
                completeJob();
            } catch (InterruptedException e) {
            }
        }).start();
    }

    protected abstract int getDuration(); // Different for each job type
    protected abstract boolean determineSuccess();

    private void completeJob() {
        isActive = false; // Job is no longer active
        boolean success = determineSuccess();
        if (success) {
            // Success logic
            workerManager.returnWorkers(workersNeeded, workerType);
            workerManager.addRecruits(workerType, workerType);
            JOptionPane.showMessageDialog(gameWindow, "Job completed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            // Failure logic
            workerManager.removeFailedWorkers(workersNeeded, workerType);
            JOptionPane.showMessageDialog(gameWindow, "Job failed!", "Failure", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isActive() {
        return isActive;
    }

    public int getWorkersNeeded() {
        return workersNeeded;
    }

    public int getWorkerType() {
        return workerType;
    }

    public boolean isSuccessful() {
        return determineSuccess();
    }
}
