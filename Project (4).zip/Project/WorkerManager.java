import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

public class WorkerManager {
    private final int[] standbyWorkers;  // Array for standby workers by type
    private final int[] workingWorkers;  // Array for working workers by type
    private final String filePath;  // Path to save the standby workers file

    public WorkerManager(int numberOfWorkerTypes, int workersPerType, String filePath) {
        this.filePath = filePath;
        standbyWorkers = new int[numberOfWorkerTypes];
        workingWorkers = new int[numberOfWorkerTypes];

        File file = new File(filePath);
        if (file.exists()) {
            loadStandbyWorkersFromFile();
        } else {
            initializeWorkers(numberOfWorkerTypes, workersPerType);
        }
    }

    private void initializeWorkers(int numberOfWorkerTypes, int workersPerType) {
        // Initialize all workers as standby
        for (int i = 0; i < numberOfWorkerTypes; i++) {
            standbyWorkers[i] = workersPerType;
            workingWorkers[i] = 0; // No workers are working initially
        }
        saveStandbyWorkersToFile();
    }

    // Assign workers to a job
    public void assignWorkersToJob(int workersToAssign, int workerType) {
        if (standbyWorkers[workerType] >= workersToAssign) {
            // Deduct workers from standby
            standbyWorkers[workerType] -= workersToAssign;
            // Add workers to the working array
            workingWorkers[workerType] += workersToAssign;
            saveStandbyWorkersToFile();
        } else {
            System.out.println("Not enough standby workers to assign.");
        }
    }

    // Return workers after job completion (success)
    public void returnWorkers(int workersReturning, int workerType) {
        if (workingWorkers[workerType] >= workersReturning) {
            workingWorkers[workerType] -= workersReturning;
            standbyWorkers[workerType] += workersReturning;
            saveStandbyWorkersToFile();
        }
    }

    // Add new recruits to standby
    public void addRecruits(int recruits, int workerType) {
        standbyWorkers[workerType] += recruits;
        saveStandbyWorkersToFile();
    }

    // Remove workers after job failure
    public void removeFailedWorkers(int workersToRemove, int workerType) {
        if (workingWorkers[workerType] >= workersToRemove) {
            workingWorkers[workerType] -= workersToRemove;
            // Note: We don't add these workers back to standby as they've failed
        }
    }

    public int[] getStandbyWorkers() {
        return standbyWorkers;
    }

    public int[] getWorkingWorkers() {
        return workingWorkers;
    }

    // Method to save standby workers to file
    private void saveStandbyWorkersToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
            for (int i = 0; i < standbyWorkers.length; i++) {
                writer.println("Worker Type " + i + ": " + standbyWorkers[i]);
            }
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }

    // Method to load standby workers from file
    private void loadStandbyWorkersFromFile() {
        try {
            Files.lines(Paths.get(filePath)).forEach(line -> {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    int workerType = Integer.parseInt(parts[0].trim().split(" ")[2]);
                    int count = Integer.parseInt(parts[1].trim());
                    standbyWorkers[workerType] = count;
                }
            });
        } catch (IOException e) {
            System.err.println("Error reading from file: " + e.getMessage());
        }
    }
}