public class HighRiskJob extends Job {
    public HighRiskJob(WorkerManager workerManager, int workersNeeded, int workerType, GameWindow gameWindow) {
        super(workerManager, workersNeeded, workerType, gameWindow);
    }

    @Override
    protected int getDuration() {
        return (int) (Math.random() * 15000) + 25000;
    }

    @Override
    protected boolean determineSuccess() {
        return Math.random() < 0.25;
    }
}
