import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;

public class JobManager {
    private WorkerManager workerManager;
    private GameWindow gameWindow;
    private final Random random;
    private static final String[] RISK_LEVELS = { "Low", "Medium", "High" };
    private final List<Job> activeJobs;

    public JobManager(WorkerManager workerManager, GameWindow gameWindow) {
        this.workerManager = workerManager;
        this.gameWindow = gameWindow;
        this.random = new Random();
        this.activeJobs = new ArrayList<>();
    }

    public JobManager(List<Job> activeJobs, Random random) {
        this.activeJobs = activeJobs;
        this.random = random;
    }

    public void createJob() {
        int workerType = random.nextInt(workerManager.getStandbyWorkers().length);
        int riskLevelIndex = determineRiskLevel();
        int workersNeeded = getWorkersNeeded(riskLevelIndex);

        if (workerManager.getStandbyWorkers()[workerType] < workersNeeded) {
            // Not enough workers available
            System.out.println("Not enough standby workers for job type " + (workerType + 1));
            return;
        }

        Job job = createJobByRiskLevel(riskLevelIndex, workersNeeded, workerType);
        String jobPrompt = String.format("A new job is available (Risk Level: %s, Worker Type: %d)! Do you want to assign %d workers?",
                                          RISK_LEVELS[riskLevelIndex], (workerType + 1), workersNeeded);
        
        int response = JOptionPane.showConfirmDialog(gameWindow, jobPrompt, "Job Available", JOptionPane.YES_NO_OPTION);

        if (response == JOptionPane.YES_OPTION) {
            assignWorkersToJob(job, workersNeeded, workerType);
        } else {
            JOptionPane.showMessageDialog(gameWindow, "Job declined. Workers remain in standby.", "Job Declined", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private Job createJobByRiskLevel(int riskLevelIndex, int workersNeeded, int workerType) {
        return switch (riskLevelIndex) {
            case 0 -> new LowRiskJob(workerManager, workersNeeded, workerType, gameWindow);
            case 1 -> new MediumRiskJob(workerManager, workersNeeded, workerType, gameWindow);
            case 2 -> new HighRiskJob(workerManager, workersNeeded, workerType, gameWindow);
            default -> null;
        }; // Should never reach here
    }

    private void assignWorkersToJob(Job job, int workersNeeded, int workerType) {
        workerManager.assignWorkersToJob(workersNeeded, workerType);
        gameWindow.updateDisplay();
        job.startJob(); // Start the job timer
        activeJobs.add(job); // Add to active jobs list
        updateActiveJobsDisplay(); // Update UI with active jobs
    }

    private void updateActiveJobsDisplay() {
        gameWindow.updateActiveJobs(activeJobs);
    }

    private int determineRiskLevel() {
        int chance = random.nextInt(10);
        if (chance < 4) return 0; // 40% for Low
        if (chance < 9) return 1; // 50% for Medium
        return 2; // 10% for High
    }

    private int getWorkersNeeded(int riskLevelIndex) {
        return switch (riskLevelIndex) {
            case 0 -> 1;
            case 1 -> 2;
            case 2 -> 3;
            default -> 0;
        };
    }
}
